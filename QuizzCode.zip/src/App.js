import React from 'react';
import QuizResultsChart from './components/QuizResultsChart';

function App() {
  return (
    <div className="App">
      <QuizResultsChart />
    </div>
  );
}

export default App;
